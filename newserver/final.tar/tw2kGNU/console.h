#ifndef _CONSOLE_H_
#define _CONSOLE_H_

void init_console(void);

#endif
