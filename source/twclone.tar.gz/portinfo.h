#ifndef PORT_INFO_H
#define PORT_INFO_H

const float buy_base_prices[3] = { 53.2, 76.5, 147.5 };
const float sell_base_prices[3] = {4.8, 21.6, 63.4 };

const char portconversion[10][3] = 
{ 
	"BBB",
	"BBS",
	"BSB",
	"BSS",
	"SBB",
	"SBS",
	"SSB",
	"SSS",
	"BBB",
	"BBB"
};


#endif
